using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIObj
{ 
    public UnityEngine.UI.Button Button(string objectName)
    {
        return GameObject.Find(objectName).GetComponent<UnityEngine.UI.Button>();
    }

    public UnityEngine.UI.Text Text(string objectName)
    {
        return GameObject.Find(objectName).GetComponent<Text>();
    }

    public static TMPro.TextMeshProUGUI TextMeshProUGUI(string objectName)
    {
        return GameObject.Find(objectName).GetComponent<TextMeshProUGUI>();
    }

    public UnityEngine.UI.InputField InputField(string objectName)
    {
        return GameObject.Find(objectName).GetComponent<InputField>();
    }

    public UnityEngine.Canvas Canvas(string objectName)
    {
        return GameObject.Find(objectName).GetComponent<Canvas>();
    }

}
