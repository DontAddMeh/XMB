using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Data;
using TMPro;
using UnityEngine.Events;
using static DatabaseManagement.Tool;

public class STARTUI : MonoBehaviour
{
    public UIPrompt PROMPT;
    public UIObj UIObjects;
    [SerializeField] UnityEvent LoadGame;


    void Initialization()
    {
        PROMPT = new UIPrompt();
        UIObjects = new UIObj();
    }


    void Start()
    {
        Initialization();

        try
        {
            int login = Convert.ToInt32(PlayerPrefs.GetString("UserID"));
            UIObjects.Canvas("STARTUI").enabled = false;
            UIObjects.Canvas("SHOPUI").enabled = false;
            UIObjects.Canvas("MAPUI").enabled = true;
            foreach (DataRow row in GetQuery($"SELECT * FROM Players WHERE UserID = '{PlayerPrefs.GetString("UserID")}';", 1).Rows)
            {
                UIObjects.Text("WELCOMETXT").text = "Welcome, " + row["Username"].ToString(); ;
            }

        }
        catch { 
        
        }

        UIObjects.Button("STARTBTN").onClick.AddListener(Play);
        UIObjects.Button("CREATEBTN").onClick.AddListener(RegUserName);

        UIObjects.Button("BACKTOMAPUI").onClick.AddListener(() => {
            UIObjects.Canvas("STARTUI").enabled = false;
            UIObjects.Canvas("SHOPUI").enabled = false;
            UIObjects.Canvas("MAPUI").enabled = true;
        });
        UIObjects.Button("ACHIEVEBACKTOMAPUI").onClick.AddListener(() => {
            UIObjects.Canvas("STARTUI").enabled = false;
            UIObjects.Canvas("SHOPUI").enabled = false;
            UIObjects.Canvas("MAPUI").enabled = true;
            UIObjects.Canvas("ACHIEVEMENTUI").enabled = false;
        });
        UIObjects.Button("BACKTOSTARTUI").onClick.AddListener(() => {
            UIObjects.Canvas("STARTUI").enabled = true;
            UIObjects.Canvas("SHOPUI").enabled = false;
            UIObjects.Canvas("MAPUI").enabled = false;
            PlayerPrefs.SetString("UserID", null);
        });
        UIObjects.Button("ENTERBTN").onClick.AddListener(() => {
            LoadGame.Invoke();
        });
        UIObjects.Button("ACHIEVEMENTBTN").onClick.AddListener(() => {
            UIObjects.Canvas("STARTUI").enabled = false;
            UIObjects.Canvas("SHOPUI").enabled = false;
            UIObjects.Canvas("MAPUI").enabled = false;
            UIObjects.Canvas("ACHIEVEMENTUI").enabled = true;
            RefreshAchievement();
        });
        
        UIObjects.Button("SHOPBTN").onClick.AddListener(() => {
            UIObjects.Canvas("STARTUI").enabled = false;
            UIObjects.Canvas("MAPUI").enabled = false;
            UIObjects.Canvas("SHOPUI").enabled = true;
            ReloadShop("ENGINESTATUSTXT", "ENGINECOSTTXT", "Speed");
            ReloadShop("FUELSTATUSTXT", "FUELCOSTTXT", "Fuel");
            UpgradeBikeStatus("UPGRADEENGINEBTN", "Speed");
            UpgradeBikeStatus("UPGRADEFUELBTN", "Fuel");
        });
    }


    void RefreshAchievement()
    {
        UIObjects.Text("LEADERBOARDTXT").text = "";
        int numberpos = 0;
        foreach (DataRow row in GetQuery($"SELECT * FROM Players GROUP BY Distance ORDER BY Distance DESC;", 1).Rows)
        {
            numberpos++;
            UIObjects.Text("LEADERBOARDTXT").text += numberpos + ". " + row["Username"].ToString() + " (" + row["Distance"].ToString() + "m)\n";
        }
    }

    void UpgradeBikeStatus(string UPGBTN, string type)
    {
        UIObjects.Button(UPGBTN).onClick.RemoveAllListeners();
        UIObjects.Button(UPGBTN).onClick.AddListener(() => {

            bool full = false;
            foreach (DataRow row in GetQuery($"SELECT * FROM Players WHERE Username = '{UIObjects.InputField("USERNAMEBOX").text}';", 1).Rows)
            {
                if (Convert.ToInt32(row[type]) == 10)
                {
                    full = true;
                }
            }

            if (!full)
            {
                int cost = Convert.ToInt32(UIObjects.Button(UPGBTN).transform.parent.transform.GetChild(3).GetComponent<Text>().text);
                int currentcoins = Convert.ToInt32(UIObjects.Button(UPGBTN).transform.parent.parent.transform.GetChild(1).GetComponent<Text>().text);
                if (currentcoins >= cost)
                {
                    currentcoins = currentcoins - cost;
                    using (
                    var CMD = GetDatabase().CreateCommand())
                    {
                        CMD.Connection = GetDatabase();
                        CMD.CommandText =
                        @"
                        UPDATE Players SET Coins = @COINS ," + type + " = " + type + "+1 WHERE userID = @USERID;";
                        CMD.Parameters.AddWithValue("@COINS", currentcoins);
                        CMD.Parameters.AddWithValue("@USERID", UIObjects.Text("USERID").text);
                        Execute(CMD);
                    }
                    PROMPT.callSuccess("[SUCCESS] Upgraded Successfully.").onClick.AddListener(() =>
                    {
                        ReloadShop("ENGINESTATUSTXT", "ENGINECOSTTXT", "Speed");
                        ReloadShop("FUELSTATUSTXT", "FUELCOSTTXT", "Fuel");
                    });
                }
                else
                {
                    PROMPT.callError("[ERROR] Insufficient Coins!");
                }
            }
            else
            {
                PROMPT.callError("[ERROR] Max Upgrade!");
            }
        });
    }


    int ReloadShop(string STATUSTXT, string COSTTXT, string stype)
    {
        int current = 0;
        foreach (DataRow row in GetQuery($"SELECT * FROM Players WHERE userID = '{UIObjects.Text("USERID").text}';", 1).Rows)
        {
            UIObjects.Text("SHOPCOINSTXT").text = row["Coins"].ToString();
            UIObjects.Text(STATUSTXT).text = row[stype].ToString();

            current = Convert.ToInt32(row[stype]);
            UIObjects.Text(COSTTXT).text = Cost(current).ToString();
        }
        return Cost(current);
    }


    int Cost(int current)
    {
        int returncost = 0;
        if (current == 0)
        {
            returncost = 0;
        }
        else if (current == 1)
        {
            returncost = 100;
        }
        else if (current == 2)
        {
            returncost = 200;
        }
        else if (current == 3)
        {
            returncost = 300;
        }
        else if (current == 4)
        {
            returncost = 400;
        }
        else if (current == 5)
        {
            returncost = 500;
        }
        else if (current == 6)
        {
            returncost = 600;
        }
        else if (current == 7)
        {
            returncost = 700;
        }
        else if (current == 8)
        {
            returncost = 800;
        }
        else if (current == 9)
        {
            returncost = 900;
        }
        else if (current == 10)
        {
            returncost = 1000;
        }
        return returncost;
    }



    void Play()
    {
        if (UIObjects.InputField("USERNAMEBOX").text != "")
        {
            string username = "";
            UIObjects.Text("USERID").text = "0";
            foreach (DataRow row in GetQuery($"SELECT * FROM Players WHERE Username = '{UIObjects.InputField("USERNAMEBOX").text}';", 1).Rows)
            {
                username = row["Username"].ToString();
                UIObjects.Text("USERID").text = row["userID"].ToString();
                PlayerPrefs.SetString("UserID", row["userID"].ToString());
            }
            if (username == "")
            {
                PROMPT.callError("[ERROR] Please create username first before play!");
            }
            else
            {

                UIObjects.Canvas("STARTUI").enabled = false;
                UIObjects.Canvas("MAPUI").enabled = true;
                UIObjects.Text("WELCOMETXT").text = "Welcome, " + username;
            }
        }
        else
        {
            PROMPT.callError("[ERROR] Please input username!");
        }
         
    }

    public void RegUserName()
    {
        if (UIObjects.InputField("USERNAMEBOX").text != "")
            {
            try
            {
                using (
                var CMD = GetDatabase().CreateCommand())
                {
                    CMD.Connection = GetDatabase();
                    CMD.CommandText =
                    @"
                    INSERT INTO Players VALUES (NULL, @USERNAME, 0, 1, 1, 0);
                ";
                    CMD.Parameters.AddWithValue("@USERNAME", UIObjects.InputField("USERNAMEBOX").text);
                    Execute(CMD);
                }
                PROMPT.callSuccess("[SUCCESS] Username created successfully.").onClick.AddListener(() => {
                    foreach (DataRow row in GetQuery($"SELECT * FROM Players WHERE Username = '{UIObjects.InputField("USERNAMEBOX").text}';", 1).Rows)
                    {
                        UIObjects.Text("WELCOMETXT").text = "Welcome, " + row["Username"].ToString();
                        UIObjects.Text("USERID").text = row["userID"].ToString();
                        PlayerPrefs.SetString("UserID", row["userID"].ToString());
                    }
                    UIObjects.Canvas("STARTUI").enabled = false;
                    UIObjects.Canvas("MAPUI").enabled = true;
                });
            }
            catch (Exception e)
            {
                PROMPT.callError("[ERROR] Username Already Exist!");
            }
        }
        else if (UIObjects.InputField("USERNAMEBOX").text == "")
        {
            PROMPT.callError("[ERROR] Username Not Allowed!");
        }
    }
}
