using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClosePrompt : MonoBehaviour
{
    void Start()
    {
        UnityEngine.UI.Button CLOSEBTN = GetComponent<Button>();
        CLOSEBTN.onClick.AddListener(Close);
    }

    void Close()
    {
        this.transform.parent.parent.parent.GetComponent<Canvas>().enabled = false; 
    }
}
