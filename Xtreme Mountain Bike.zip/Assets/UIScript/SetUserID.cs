using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SetUserID : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        Text ID = GetComponent<Text>();
        ID.text = PlayerPrefs.GetString("UserID");
    }
}
