using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIPrompt
{
    public GameObject ErrorPromptUI = GameObject.Find("PROMPTERROR");
    public GameObject SuccessPromptUI = GameObject.Find("PROMPTSUCCESS");
    public Button SUCCESSBTN = GameObject.Find("SUCCESSBTN").GetComponent<Button>();
    public Text errorTitle = GameObject.Find("ErrorTitle").GetComponent<Text>();
    public Text successTitle = GameObject.Find("SuccessTitle").GetComponent<Text>();
    public void callError(string t)
    {
        errorTitle.text = t;
        ErrorPromptUI.GetComponent<Canvas>().enabled = true;
    }
    public Button callSuccess(string t)
    {
        successTitle.text = t;
        SuccessPromptUI.GetComponent<Canvas>().enabled = true;
        return SUCCESSBTN;
    }
}