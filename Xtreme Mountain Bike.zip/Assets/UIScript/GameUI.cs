using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Data;
using TMPro;
using UnityEngine.Events;
using static DatabaseManagement.Tool;

public class GAMEUI : MonoBehaviour
{
    public UIObj UIObjects;
    [SerializeField] UnityEvent BackGame;
    [SerializeField] UnityEvent TryGame;
    void Initialization()
    {
        UIObjects = new UIObj();
    }


    void Start()
    {
        Initialization();

        UIObjects.Button("HOMEBTN").onClick.AddListener(() => {
            BackGame.Invoke();
        });
        UIObjects.Button("RESUMEBTN").onClick.AddListener(() => {
            UIObjects.Canvas("MENUUI").enabled = false;
        });
        UIObjects.Button("PAUSEBTN").onClick.AddListener(() => {
            UIObjects.Canvas("MENUUI").enabled = true;
        });
        UIObjects.Button("TRYBTN").onClick.AddListener(() => {
            TryGame.Invoke();
        });
    }
}
