using UnityEngine;
using UnityEngine.U2D;

public class TerrainCreator : MonoBehaviour
{
    public SpriteShapeController shape;
    public int scale = 5000;
    public int numofPoints = 100;

    private void Start()
    {
        float distanceBwtnpoints = (float)scale / (float)numofPoints;
        shape = GetComponent<SpriteShapeController>();
        shape.spline.SetPosition(2, shape.spline.GetPosition(2) + Vector3.right * scale);

        for (int i = 0; i < 150; i++)
        {
          
            float xPos = shape.spline.GetPosition(i + 1).x + distanceBwtnpoints;
            shape.spline.InsertPointAt(i + 2, new Vector3(xPos, i * Random.Range(5.0f, 6.0f), 0));
        }

        for (int i = 2; i < 152; i++)
        {
            shape.spline.SetTangentMode(i, ShapeTangentMode.Continuous);
            shape.spline.SetLeftTangent(i, new Vector3(-2, 0, 0));
            shape.spline.SetRightTangent(i, new Vector3(2, 0, 0));
        }
    }
}