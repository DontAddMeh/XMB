using UnityEngine;
using System;
using System.Data;
using System.Globalization;
using static DatabaseManagement.Tool;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(CircleCollider2D))]
public class Wheel : MonoBehaviour
{
    enum State { Moves, Braking, Idle};
    State state = State.Idle;

    [Header("Required components")]
    [SerializeField] WheelJoint2D wheelJoint;

    [SerializeField] ParticleSystem dirtParticles;

    [Header("Speed and power")]

    float maxDriveSpeed = 0f;
    float power = 0f;

    [SerializeField] string groundTag = "Ground";


    bool onGround;
    public UIObj UIObjects;
    void Start()
    {
        UIObjects = new UIObj();
        foreach (DataRow row in GetQuery($"SELECT * FROM Players WHERE userID = '{PlayerPrefs.GetString("UserID")}';", 1).Rows)
        {
            int level = Convert.ToInt32(row["Speed"].ToString());
            if (level == 1)
            {
                maxDriveSpeed = 1500f;
                power = 1000f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
            else if (level == 2)
            {
                maxDriveSpeed = 2500f;
                power = 2000f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
            else if (level == 3)
            {
                maxDriveSpeed = 3500f;
                power = 3000f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
            else if (level == 4)
            {
                maxDriveSpeed = 4500f;
                power = 4000f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
            else if (level == 5)
            {
                maxDriveSpeed = 5500f;
                power = 5000f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
            else if (level == 6)
            {
                maxDriveSpeed = 5500f;
                power = 5100f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
            else if (level == 7)
            {
                maxDriveSpeed = 5500f;
                power = 5200f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
            else if (level == 8)
            {
                maxDriveSpeed = 5500f;
                power = 5300f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
            else if (level == 9)
            {
                maxDriveSpeed = 5500f;
                power = 5400f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
            else if (level == 10)
            {
                maxDriveSpeed = 5500f;
                power = 5500f;
                UIObjects.Text("GEARTXT").text = "Gear: " + level.ToString();
            }
        }
    }

    void Update()
    {
        HandleParticles();
    }

    void HandleParticles()
	{
        if (state == State.Idle || !OnGround()) { dirtParticles.Stop(); return; }
        else if (OnGround()) dirtParticles.Play();

		var velocityOverLifetime = dirtParticles.velocityOverLifetime;
		if (state == State.Moves)
		{
            if (wheelJoint.motor.motorSpeed < 0) velocityOverLifetime.xMultiplier = -7f;
            else if (wheelJoint.motor.motorSpeed > 0) velocityOverLifetime.xMultiplier = 7f;
        }
		else if (state == State.Braking) velocityOverLifetime.xMultiplier = 7f;
	}

    public void Move(float input)
	{
        state = State.Moves;
        wheelJoint.useMotor = true;
        wheelJoint.motor = new JointMotor2D { motorSpeed = input * maxDriveSpeed, maxMotorTorque = power };
        Debug.Log(wheelJoint.connectedBody);
        Debug.Log(wheelJoint.transform.name);
    }

    public void Stop()
	{
        state = State.Braking;
        wheelJoint.useMotor = true;
        wheelJoint.motor = new JointMotor2D { motorSpeed = 0f, maxMotorTorque = power };
    }

    public void Idle()
	{
        state = State.Idle;
        wheelJoint.useMotor = false;
    }

    public bool OnGround()
	{
        return onGround;
	}

    public float GetMaxSpeed()
	{
        return maxDriveSpeed;
	}

	void OnCollisionEnter2D(Collision2D collision)
	{
		if (collision.transform.CompareTag(groundTag))
		{
            onGround = true;
		}
	}

	void OnCollisionExit2D(Collision2D collision)
	{
        if (collision.transform.CompareTag(groundTag))
        {
            onGround = false;
        }
    }
}
