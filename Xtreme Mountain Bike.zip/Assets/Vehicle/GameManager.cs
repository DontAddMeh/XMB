using UnityEngine;
using System;
using System.Data;
using System.Globalization;
using static DatabaseManagement.Tool;


public class GameManager : MonoBehaviour
{
	UIController uiController;

	[SerializeField] float fuelUsage = 0.05f;
	float fuelLevel = 1f;
    public UIObj UIObjects;

    void Start()
	{
        UIObjects = new UIObj();
        Time.timeScale = 0.9f;
		uiController = GameObject.Find("MOTORUI").GetComponent<UIController>();
        foreach (DataRow row in GetQuery($"SELECT * FROM Players WHERE userID = '{PlayerPrefs.GetString("UserID")}';", 1).Rows)
        {
            uiController.UpdateCoins(row["Coins"].ToString());
            fuelLevel = float.Parse(row["Fuel"].ToString(), CultureInfo.InvariantCulture.NumberFormat);
        }
    }

	void Update()
	{
		UseFuel();
	}

	void UseFuel()
	{
		if (fuelLevel > fuelUsage * Time.deltaTime)		
		{
			fuelLevel -= fuelUsage * Time.deltaTime;
		}
        uiController.UpdateFuelLevel(fuelLevel);
    }

	public void Refuel()
	{
		fuelLevel += 1f;
	}

	public float GetFuelLevel()
	{
		return fuelLevel;
	}

	public bool IsFuel()
	{
        return Math.Round(fuelLevel, 1) > 0 ? true : false;
	}

	public void AddCoins()
	{
        using (
		var CMD = GetDatabase().CreateCommand())
        {
            CMD.Connection = GetDatabase();
            CMD.CommandText =
            @"
             UPDATE Players SET Coins = Coins + 20 WHERE userID = @USERID;";
            CMD.Parameters.AddWithValue("@USERID", PlayerPrefs.GetString("UserID"));
            Execute(CMD);

        }
        uiController.UpdateCoins((Convert.ToInt32(UIObjects.Text("COINSTXT").text) + 20).ToString());

    }

	public void Pause()
	{
		Time.timeScale = 0f;
	}

	public void Resume()
	{
		Time.timeScale = 0.9f;
	}

	public void Exit()
	{
		Application.Quit();
	}
}
