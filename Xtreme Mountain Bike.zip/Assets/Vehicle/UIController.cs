using UnityEngine;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{
    [Header("Fuel")]
    [SerializeField] Slider fuelLevelSlider;

    [Header("Coins")]
    [SerializeField] Text coinsText;

    public void UpdateFuelLevel(float newLevel)
	{
        fuelLevelSlider.value = newLevel;
	}

    public void UpdateCoins(string newScore)
	{
        coinsText.text = newScore;
	}

}
