using UnityEngine;
using UnityEngine.UI;
using System;
using System.Data;
using System.Globalization;
using static DatabaseManagement.Tool;

[RequireComponent(typeof(Text))]
public class Distance : MonoBehaviour
{
    [SerializeField] Transform car;

    Text text;
    int playerdistance;
    int currentDistance;
    int levelDistance = 100;
    int bestDistance;

    public UIObj UIObjects;

    void Start()
    {
        UIObjects = new UIObj();
        text = GetComponent<Text>();
        foreach (DataRow row in GetQuery($"SELECT CASE WHEN Distance IS NULL THEN 0 ELSE Distance END AS Distance FROM Players GROUP BY Distance ORDER BY Distance DESC LIMIT 1;", 1).Rows)
        {
            bestDistance = Convert.ToInt32(row["Distance"]);
        }
        foreach (DataRow row in GetQuery($"SELECT Distance FROM Players WHERE userID = '{PlayerPrefs.GetString("UserID")}';", 1).Rows)
        {
            playerdistance = Convert.ToInt32(row["Distance"]);
        }
    }

    void Update()
    {
        currentDistance = Mathf.RoundToInt(car.position.x - Vector2.zero.x);
        if (currentDistance > levelDistance) levelDistance += 100;
        text.text = currentDistance.ToString() + "m / " + levelDistance.ToString() + "m (highest: " + bestDistance.ToString() + "m)";
    }

    public void SaveBestDistance()
	{
        UIObjects = new UIObj();
        UIObjects.Text("BESTSCORETXT").text = "Score: " + currentDistance +"m";
        if (currentDistance > playerdistance)
        {
            using (
            var CMD = GetDatabase().CreateCommand())
            {
                CMD.Connection = GetDatabase();
                CMD.CommandText =
                @"
                UPDATE Players SET Distance = @DISTANCE WHERE userID = @USERID;";
                CMD.Parameters.AddWithValue("@USERID", PlayerPrefs.GetString("UserID"));
                CMD.Parameters.AddWithValue("@DISTANCE", currentDistance);
                Execute(CMD);

            }
        }
    }
}
