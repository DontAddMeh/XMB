using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;

public class FuelLevel : MonoBehaviour
{
    [SerializeField] Text distanceToFuel;
    [SerializeField] Transform car;

    void Update()
    {
        GameManager gm = GameObject.Find("Game Manager").GetComponent<GameManager>();
        distanceToFuel.text = Math.Round(gm.GetFuelLevel(), 1).ToString();
    }

}
