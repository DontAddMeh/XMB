using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(CircleCollider2D))]
public class Spike : MonoBehaviour
{
	[SerializeField] string playerTag = "Player";
    [SerializeField] UnityEvent OnPlayerDeath;
    public UIObj UIObjects;
    void Start()
	{
        UIObjects = new UIObj();
    }

	void OnTriggerEnter2D(Collider2D collision)
	{
		if (collision.CompareTag(playerTag))
		{
            UIObjects.Canvas("DeathUI").enabled = true;
            OnPlayerDeath.Invoke();
            Destroy(gameObject, 2f);
		}
	}
}
