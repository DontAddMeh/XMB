using System.Collections;
using UnityEngine;
using sm = UnityEngine.SceneManagement;

public class SceneManager : MonoBehaviour
{

    public void ResetLevel()
    {
        int currentSceneIndex = sm.SceneManager.GetActiveScene().buildIndex;
        LoadScene(currentSceneIndex);
    }

    public void PreviousScene()
    {
        int previousSceneIndex = sm.SceneManager.GetActiveScene().buildIndex - 1;
        LoadScene(previousSceneIndex);
    }

    public void NextScene()
    {
        int nextSceneIndex = sm.SceneManager.GetActiveScene().buildIndex + 1;
        LoadScene(nextSceneIndex);
    }

    public void LoadScene(int sceneIndex) {
        sm.SceneManager.LoadSceneAsync(sceneIndex);
    }
}
