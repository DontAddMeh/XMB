
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mono.Data.Sqlite;
using System.Data;
using System.IO;


namespace DatabaseManagement
{
    class Tool
    {
        static SqliteConnection Database;
        public static void Execute(SqliteCommand SQLCON)
        {
            SQLCON.ExecuteNonQuery();
            Database.Close();
        }

        public static SqliteConnection GetDatabase()
        {
            string conn = "";
            conn = "URI=file:" + Application.dataPath + "\\DataBase\\MainDatabase" + "/DataBase.db";
            Database = new SqliteConnection(conn);
            Database.Open();
            return Database;
        }

        public static DataTable GetQuery(string Query, int condition) // 1 table refresh, 0 no refresh;
        {
            DataTable Table = new DataTable();
            IDbCommand cmnd_read = GetDatabase().CreateCommand();
            cmnd_read.CommandText = Query;
            IDataReader reader = cmnd_read.ExecuteReader();
            if (condition == 1) { Table.Clear(); }
            Table.Load(reader);
            return Table;
        }
    }
}



